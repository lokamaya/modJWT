<?php
/**
 * jwtOnAuthorization plugin for modJWT extra
 *
 * NOT USED. Reserved for further development.
 *
 * @package modjwt
 */