modJWT

Author: Zaenal <zaenal(#)lokamaya.com>
Copyright (C) 2019

Official Documentation: https://github.com/lokamaya/modJWT
Bugs and Feature Requests: https://github.com/lokamaya/modJWT
Questions: http://forums.modx.com

Created by MyComponent
